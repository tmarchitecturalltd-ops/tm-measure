# Design System Document: Architectural Editorial

## 1. Overview & Creative North Star

### Creative North Star: "The Structural Gallery"
This design system moves beyond the standard "SaaS dashboard" aesthetic to embrace the precision of modern architecture and the sophistication of high-end editorial layouts. We do not just display data; we curate it within a digital environment that feels permanent, intentional, and premium.

The visual language is defined by **The Structural Gallery**—a concept where negative space is treated as a physical material, and content is housed in "rooms" defined by light and shadow rather than lines and boxes. We lean into intentional asymmetry and dramatic typographic scales to break the monotony of traditional grids, ensuring 'TM Measure' feels like an authoritative tool for professionals.

---

## 2. Colors

Our palette is rooted in the interplay between deep "Foundational Navy" and "Structural Neutrals," punctuated by "Warm Gold" accents that mimic high-end architectural finishes (like brass or gold leaf).

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or containment. 
Boundaries must be defined through:
- **Background Color Shifts:** Placing a `surface_container_low` element against a `surface` background.
- **Tonal Transitions:** Using depth and layering to imply where one zone ends and another begins.

### Surface Hierarchy & Nesting
Treat the UI as a physical model. Use the `surface_container` tiers to create nested depth:
- **Base Layer:** `surface` (#F9F9F7) or `surface_dim`.
- **Primary Containers:** `surface_container_low` (#F4F4F2) for large content areas.
- **Interactive Elements:** `surface_container_lowest` (#FFFFFF) for cards that need to "pop" or draw focus.

### The "Glass & Gradient" Rule
To avoid a flat, "templated" look, use **Glassmorphism** for floating elements (e.g., navigation bars, tooltips). Use `surface` colors at 80% opacity with a `16px` to `32px` backdrop-blur. 
- **Signature Texture:** For primary CTAs or Hero sections, apply a subtle linear gradient from `primary` (#002452) to `primary_container` (#1B3A6B) at a 135-degree angle. This adds a "soul" to the navy that flat hex codes cannot achieve.

---

## 3. Typography

Typography is the "infrastructure" of this system. We use **Inter** with high contrast between weights and sizes to create an editorial rhythm.

- **Display & Headlines:** Use `display-lg` and `headline-lg` in SemiBold. These are the anchors of the page. Use generous tracking (-0.02em) to make large type feel tighter and more premium.
- **Data & Title:** In 'TM Measure', data is king. Use `title-md` in SemiBold for all measurement values. This conveys authority and precision.
- **Body & Labels:** Use `body-md` in Regular for long-form text. Labels (`label-md`) should always be in SemiBold to maintain the "architectural blueprint" aesthetic.

**Editorial Tip:** Don't be afraid of "wasted" space. Align a `display-md` headline to the far left and keep the right 40% of the container empty to create a sophisticated, asymmetrical tension.

---

## 4. Elevation & Depth

We achieve hierarchy through **Tonal Layering** rather than traditional structural lines.

### The Layering Principle
Depth is achieved by "stacking" the surface tiers. For example, a card (`surface_container_lowest`) sitting on a section background (`surface_container_low`) creates a soft, natural lift.

### Ambient Shadows
When an element must float (like a Modal or FAB), use "Ambient Shadows":
- **Shadow Color:** Use a tinted version of `on_surface` (a deep navy-grey) at 4%–8% opacity.
- **Properties:** Large blur values (24px to 48px) and 0px spread. This mimics natural light falling across a physical architectural model.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., in high-contrast scenarios), use a **Ghost Border**:
- **Token:** `outline_variant` at 15% opacity. 100% opaque borders are strictly forbidden.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`). 8px (`lg`) roundedness. SemiBold `label-md` text.
- **Secondary:** `secondary_fixed` (Warm Gold) background with `on_secondary_fixed` text. Use this for the most important "Premium" actions.
- **Tertiary:** No background. Use `primary` text with an underline that only appears on hover.

### Cards & Lists
- **Rule:** Forbid divider lines. 
- **Execution:** Separate list items using 16px of vertical white space or by alternating background tones (`surface` vs `surface_container_low`). 
- **Cards:** Use `surface_container_lowest` with a `0.5rem` (`lg`) rounded corner and an ambient shadow for high-priority measurements.

### Input Fields
- **Style:** Underline-only or Ghost-Border.
- **Focus State:** The label should animate into a `label-sm` SemiBold position in `secondary` (Gold), and the underline/border should transition to `secondary`. This feels like a "light" turning on in a room.

### Measurement Chips
- **Contextual Component:** Since this is 'TM Measure', use chips to display status or units. 
- **Style:** `surface_container_high` background with `on_surface_variant` text. No border.

---

## 6. Do's and Don'ts

### Do
- **Do** use intentional asymmetry. Align a title to the left and a CTA to the far right with vast empty space between them.
- **Do** use "Surface-on-Surface" layering to define content blocks.
- **Do** treat numbers as "Hero" elements. Scale them up; make them bold.
- **Do** use the Warm Gold (`secondary`) sparingly—it is a jeweler's touch, not a primary paint.

### Don't
- **Don't** use 1px solid black or grey borders to separate sections.
- **Don't** use standard "Drop Shadows" (high opacity, small blur).
- **Don't** crowd the layout. If a screen feels "full," it needs more white space.
- **Don't** use pure black (#000000) for text. Use `on_surface` (#1A1C1B) for a softer, more premium readability.